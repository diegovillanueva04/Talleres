package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {

	public static double IMPUESTO = 0.28;
	private Cliente cliente;
	private Vuelo vuelo; 
	
	public int calcularTarifa( Vuelo vuelo, Cliente cliente) {	
		return null;
	}
	
	private int calcularCostoBase( Vuelo vuelo, Cliente cliente) {	
		return null;
	}
	private double calcularPorcentajeDescuento( Cliente cliente) {	
		return null;
	}
	private int calcularDistanciaVuelo( Ruta ruta) {	
		return null;
	}
	private int calcularValorImpuesto( int costoBase) {	
		return null;
	}
	
	
}
