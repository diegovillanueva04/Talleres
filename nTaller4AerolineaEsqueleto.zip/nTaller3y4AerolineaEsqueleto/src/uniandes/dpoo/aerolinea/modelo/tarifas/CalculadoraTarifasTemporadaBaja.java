package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas{

	
	private static final int COSTO_POR_KM_NATURAL = 600;
	private static final int COSTO_POR_KM_CORPORATIVO = 900;
	private static final double DESCUENTO_PEQ = 0.02;
	private static final double DESCUENTO_MEDIANAS = 0.1;
	private static final double DESCUENTO_GRANDES = 0.2;

	
	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        int distanciaVuelo = calcularDistanciaVuelo(vuelo.getRuta());
        return (boolean) cliente.getTipoCliente() ? COSTO_POR_KM_CORPORATIVO * distanciaVuelo : COSTO_POR_KM_NATURAL * distanciaVuelo;
    }

    public double calcularPorcentajeDescuento(Cliente cliente) {
        if ((boolean) cliente.getTipoCliente())  {
                case PEQUENA:
                    return DESCUENTO_PEQ;
                case MEDIANA:
                    return DESCUENTO_MEDIANAS;
                case GRANDE:
                    return DESCUENTO_GRANDES;
                default:
                    return 0;
            }
        } else {
            return 0;
        }
    }
}
