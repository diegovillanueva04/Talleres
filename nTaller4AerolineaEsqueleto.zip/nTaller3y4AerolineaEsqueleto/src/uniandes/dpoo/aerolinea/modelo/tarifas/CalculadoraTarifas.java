package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {

	public static double IMPUESTO = 0.28;
	private Cliente cliente;
	private Vuelo vuelo; 
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
        int costoBase = calcularCostoBase(vuelo, cliente);
        double porcentajeDescuento = calcularPorcentajeDescuento(cliente);

        int impuestos = calcularValorImpuestos(costoBase);
        return (int) Math.round((costoBase - (costoBase * porcentajeDescuento)) + impuestos);
    }

    protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);

    protected abstract double calcularPorcentajeDescuento(Cliente cliente);

    protected int calcularDistanciaVuelo(Ruta ruta) {
        double lat1 = Math.toRadians(ruta.getOrigen().getLatitud());
        double lon1 = Math.toRadians(ruta.getOrigen().getLongitud());
        double lat2 = Math.toRadians(ruta.getDestino().getLatitud());
        double lon2 = Math.toRadians(ruta.getDestino().getLongitud());

        double deltaLat = lat2 - lat1;
        double deltaLon = lon2 - lon1;

        double a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                   Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double r = 6371;

        return (int) Math.round(r * c);
    }

    private int calcularValorImpuestos(int costoBase) {
        return (int) Math.round(costoBase * IMPUESTO);
    }
	
	
}
