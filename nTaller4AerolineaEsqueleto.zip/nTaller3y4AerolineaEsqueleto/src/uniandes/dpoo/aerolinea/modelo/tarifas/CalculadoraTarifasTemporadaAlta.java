package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas{

	private static int COSTO_POR_KM = 1000;
	
	
	
    public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        int distanciaVuelo = calcularDistanciaVuelo(vuelo.getRuta());
        return COSTO_POR_KM * distanciaVuelo;
    }

	
	public double calcularPorcentajeDescuento(Cliente cliente) {
	return 0;

	}
	
	
	
}
