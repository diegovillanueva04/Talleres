package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.LinkedList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {

	
	private List< Tiquete > tiquetesSinUsar;
	private List< Tiquete > tiquetesUsados;
	
	public Cliente() {
		tiquetesSinUsar =  new LinkedList <Tiquete>();
		tiquetesUsados =  new LinkedList <Tiquete>();
	}
	
	public boolean getTipoCliente() {
		return null;
	}
	public String getIdentificador() {
		return null;
	}
	public Void agregarTiquete(Tiquete tiquete) {
		return null;
	}
	public int calcularValorTotalTiquetes() {
		return null;
	}
	public void usarTiquetes(Vuelo vuelo) {
		return null;
	}
	
	
}
