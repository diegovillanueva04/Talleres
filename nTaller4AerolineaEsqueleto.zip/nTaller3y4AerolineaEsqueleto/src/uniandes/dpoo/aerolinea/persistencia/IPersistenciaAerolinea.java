package uniandes.dpoo.aerolinea.persistencia;

public class IPersistenciaAerolinea {

}
